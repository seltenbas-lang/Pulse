#!/usr/bin/env bash
# Makes the Android signing key ONCE and stores it as the two repo secrets the workflow reads.
# Run it in a GitHub Codespace (or any terminal with a JDK) opened on your repo:  bash tools/make-android-key.sh
set -euo pipefail
command -v keytool >/dev/null || { echo "keytool not found: install a JDK first"; exit 1; }
pw="$(head -c 48 /dev/urandom | base64 | tr -dc 'A-Za-z0-9' | head -c 24)"
dir="$(mktemp -d)"
keytool -genkeypair -storetype PKCS12 -keystore "$dir/pulse-release.p12" -alias pulse \
  -keyalg RSA -keysize 2048 -validity 36500 -storepass "$pw" -dname "CN=Pulse" >/dev/null 2>&1
b64="$(base64 -w0 "$dir/pulse-release.p12")"
if command -v gh >/dev/null 2>&1 \
  && printf %s "$b64" | gh secret set PULSE_KEYSTORE_B64 >/dev/null 2>&1 \
  && printf %s "$pw" | gh secret set PULSE_KEYSTORE_PASSWORD >/dev/null 2>&1; then
  echo "Saved PULSE_KEYSTORE_B64 and PULSE_KEYSTORE_PASSWORD as secrets on this repo. Done."
else
  echo "Couldn't save the secrets automatically. On GitHub open the repo > Settings > Secrets and variables > Actions"
  echo "> New repository secret, and add these two (exact names):"
  echo; echo "PULSE_KEYSTORE_PASSWORD"; echo "$pw"
  echo; echo "PULSE_KEYSTORE_B64"; echo "$b64"
fi
echo
echo "The key file is $dir/pulse-release.p12. GitHub can't show secrets again, so keep a copy if you want to be able"
echo "to rebuild the key later. If it is ever lost, make a new one and uninstall Pulse once before installing."
